# Zenkai League CEO — Deploy no Netlify

Este pacote foi ajustado para funcionar no Netlify usando o Vite.

## Como publicar (via Git recomendado)

1. Crie um repositório no GitHub/GitLab/Bitbucket e faça push deste conteúdo.
2. No Netlify, clique em **Add new site → Import an existing project**.
3. Conecte o repositório.
4. Confirme as configurações de build:
   - **Build command:** `npm install && npm run build`
   - **Publish directory:** `dist`
   - **Node version:** 20 (definida em `netlify.toml`)
5. (Opcional) Em **Site configuration → Environment variables**, adicione variáveis de ambiente necessárias. *Atenção:* qualquer chave incluída no bundle front-end fica pública no navegador.
6. Deploy!

## Por que não dá para usar "Drag & Drop" direto?
O Netlify **Drag & Drop** aceita apenas pastas **já compiladas** (estáticas). Como este projeto usa Vite + React/TypeScript, ele precisa do passo de build para gerar a pasta `dist`. O fluxo via Git deixa o Netlify fazer esse build automaticamente.

## Observações
- `index.html` foi simplificado para o padrão Vite (removeu import maps e um script duplicado para evitar conflitos).
- `netlify.toml` já inclui um redirect `/* → /index.html (200)` para single‑page apps.
- Se futuramente você adicionar rotas com react-router, o redirect já cobre.
- O arquivo `.env.local` tem apenas um placeholder e **não** é usado pelo código (apenas referenciado em `vite.config.ts` caso você venha a configurar algo no futuro). Prefira variáveis de ambiente no painel do Netlify.
