// This file is now obsolete. The trainer image system was updated to fetch images dynamically from GitHub.
// This file is no longer used by the application and can be safely removed in the future.
export const TRAINER_IMAGES: { [key: string]: string } = {};
