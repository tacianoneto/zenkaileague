
import React from 'react';

// This component is currently not used and was referencing deprecated state.
// Returning null to fix compilation errors.
export const Headquarters: React.FC = () => {
    return null;
};
