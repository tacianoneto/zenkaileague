import React, { useState } from 'react';
import { Layout } from './components/Layout.js';
import { HubCentral } from './components/tabs/HubCentral.js';
import { Gyms } from './components/tabs/Gyms.js';
import { Trainers } from './components/tabs/Trainers.js';
import { Zenkais } from './components/tabs/Zenkais.js';
import { Expeditions } from './components/tabs/Expeditions.js';
import { Training } from './components/tabs/Training.js';
import { Infrastructure } from './components/tabs/Infrastructure.js';
import { Finances } from './components/tabs/Finances.js';
import { Ranking } from './components/tabs/Ranking.js';
import { useGameState } from './hooks/useGameState.js';
import { GameOverModal } from './components/GameOverModal.js';
import { EndOfSeasonModal } from './components/EndOfSeasonModal.js';
import { Sponsorships } from './components/tabs/Sponsorships.js';
import { Missions } from './components/tabs/Missions.js';

const App = () => {
    const [activeTab, setActiveTab] = useState('Hub');
    const gameState = useGameState();

    const renderContent = () => {
        switch (activeTab) {
            case 'Hub':
                return React.createElement(HubCentral, { gameState: gameState });
            case 'Gyms':
                return React.createElement(Gyms, { gameState: gameState });
            case 'Trainers':
                return React.createElement(Trainers, { gameState: gameState });
            case 'Zenkais':
                return React.createElement(Zenkais, { gameState: gameState });
            case 'Expeditions':
                return React.createElement(Expeditions, { gameState: gameState });
            case 'Training':
                return React.createElement(Training, { gameState: gameState });
            case 'Missions':
                return React.createElement(Missions, { gameState: gameState });
            case 'Sponsorships':
                return React.createElement(Sponsorships, { gameState: gameState });
            case 'Infrastructure':
                return React.createElement(Infrastructure, { gameState: gameState });
            case 'Finances':
                return React.createElement(Finances, { gameState: gameState });
            case 'Ranking':
                return React.createElement(Ranking, { gameState: gameState });
            default:
                return React.createElement(HubCentral, { gameState: gameState });
        }
    };

    return (
        React.createElement(React.Fragment, null,
            React.createElement(Layout, { activeTab: activeTab, setActiveTab: setActiveTab, gameState: gameState },
                renderContent()
            ),
            gameState.gameState.isGameOver && React.createElement(GameOverModal, { gameState: gameState }),
            gameState.gameState.isEndOfSeason && React.createElement(EndOfSeasonModal, { gameStateHook: gameState })
        )
    );
};

export default App;
